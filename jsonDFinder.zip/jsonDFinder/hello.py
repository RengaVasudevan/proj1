#!/usr/bin/python

from jsondiff import diff
import json
import requests
with open('a.json', 'r') as first_json:
  localJson = json.loads(str(first_json.read()))

  prodJson = json.loads((requests.get('https://jsonplaceholder.typicode.com/posts?userId=1')).text)
  
diffJsonLocal = diff(prodJson, localJson, syntax='explicit')
diffJsonProd = diff(localJson, prodJson)

if str(diffJsonLocal) == '{}':
 print('No Differences found')
else:
 print("differences present in local\n",diffJsonLocal,'\n\n')
 print("Actual content in prod\n",diffJsonProd,"\n\n")

 #print((requests.get('https://jsonplaceholder.typicode.com/todos/2')).text)