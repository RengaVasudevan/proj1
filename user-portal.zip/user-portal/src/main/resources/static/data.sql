create table user (id integer not null auto_increment, email varchar(255), first_name varchar(255), last_name varchar(255), primary key (id))

	insert into  user values(1,'spitchai@gmail.com','Sundar','Pitchai')
	
	select * from user;