import { Component, OnInit,Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../models/user.model';
import { UserService } from './user.service';


@Component({
  selector: 'app-searchuser',
  templateUrl: './search-user.component.html',
  styles: []
})

@Pipe({name: 'keyPipe'})
export class SearchUserComponent implements PipeTransform {

  users: any;
  showDetails = false;
  noRecord = false;
  updatedUserDet: User = new User();
  constructor(private router: Router, private userService: UserService) {

  }

  searchUser(id): any {
    this.userService.getUser(id)
    .subscribe( data => {
      this.toggle(data);
      this.users = this.transform(data);
    });
  }

  transform(data): any {
   let trVar = [];
   for (let key in data) {
   trVar.push({key: key,value : data[key]});
   }
   return trVar;
  }

  toggle(data): void{
   if(data != null) {
     this.showDetails = true;
     this.noRecord = false;
   }else {
    this.showDetails = false;
    this.noRecord = true;
   }
  }

   updateUser(): void {
     this.updatedUserDet.id = this.users[0].value;
     this.updatedUserDet.firstName = this.users[1].value;
     this.updatedUserDet.lastName = this.users[2].value;
     this.updatedUserDet.email = this.users[3].value;
    this.userService.updateUser(this.updatedUserDet)
        .subscribe( data => {
          alert('User with ID ' + this.updatedUserDet.id + ' updated successfully.');
          this.showDetails = false;
        });
  };

}


